package test.ui;

public class TestMain {
	public static void main(String[] args) {
		PlayUI ui = new PlayUI();

				
	}
}
