package test.ui;

import java.util.Random;
import java.util.Scanner;
import java.util.ArrayList;

import test.vo.Player;
import test.dao.PlayerDAO;


public class PlayUI {
    private String[] rcp = {"가위", "바위", "보"};
    private String computer;

    Scanner sc = new Scanner(System.in);
    PlayerDAO dao = new PlayerDAO();

    public PlayUI(){
        while(true){
            printMainMenu();
            int select = sc.nextInt();
            sc.nextLine();

            switch(select){
                case 1:
                    createPlayerMenu();
                    break;
                case 2:
                    rcpMenu();
                    break;
                case 3:
                    ranklist();
                case 0:
                    System.out.println("프로그램을 종료합니다.");
                    return;
            }
        }

    }
    
    public void printMainMenu(){        
        System.out.println("----------------------");
        System.out.println("  가위바위보 program");
        System.out.println("----------------------");
        System.out.println("1. 플레이어 등록");
        System.out.println("2. 가위바위보");
        System.out.println("3. 랭크 확인");
        System.out.println("0. 종료");
        System.out.println("----------------------");
        System.out.print("입력 : ");
        
    }

    public void createPlayerMenu(){
        System.out.println("플레이어 등록");
        System.out.println("----------------------");
        System.out.print("이름을 입력하세요: ");
        String name = sc.nextLine();

        Player p = new Player(name);
        int result = dao.createPlayer(p);
        if(result == 0){
            System.out.println("----------------------");
            System.out.println("플레이어 등록 실패!\n");
            return;
        }
        System.out.println("----------------------");
        System.out.println("* 등록되었습니다!\n");
        
               
    }
    
    public Player selectPlayer(){
        ArrayList<Player> list = dao.printName();
        for(Player temp : list) System.out.println(temp.getName());
        System.out.print("플레이어를 선택하세요 : ");
        String name = sc.nextLine();

        Player p1 = dao.selectByName(name);
        if(p1 != null) {
            System.err.println(name+" 플레이어로 가위바위보를 시작합니다.");
            return p1;
        }
        else {
            System.out.println("선택하신 이름이 없습니다.\n");
            return p1;
        }
    }

    public void rcpMenu(){
        while(true){
            System.out.println("가위바위보");
            Player p = selectPlayer();
            if(p==null) return;

            System.out.println("----------------------");
            System.out.print("\'가위\', \'바위\', \'보\' 중에 하나를 입력하세요: ");
            String rcp = sc.nextLine();
            if(!rcp.equals("가위") || !rcp.equals("바위") || !rcp.equals("보")){
                System.out.println("\'가위\' \'바위\' \'보\' 중에 입력해주세요");
                continue;
            }
            
            int result = rcpGame(rcp);
            if(result == -1){ //졌을 때

                System.out.println("당신의 패: "+rcp);
                System.out.println("컴퓨터의 패: "+computer);

                System.out.println("당신이 졌습니다!");
                total_incre(p);
                lose_incre(p);
            }
            else if(result == 1){ //이겼을 때
                System.out.println("당신의 패: "+rcp);
                System.out.println("컴퓨터의 패: "+computer);

                System.out.println("당신이 이겼습니다!");
                total_incre(p);
                win_incre(p);
            }
            else if (result ==0){ //비겼을 때
                System.out.println("당신의 패: "+rcp);
                System.out.println("컴퓨터의 패: "+computer);

                System.out.println("비겼습니다!");
                total_incre(p);

            }
        }

    }

    public int rcpGame(String input){
        int player = 0;
        
        if(input.equals("가위")) player = 1;
        else if(input.equals("바위")) player = 2;
        else if(input.equals("보")) player = 3;
        
        Random rand = new Random();
        int com = rand.nextInt(3)+1;

        computer = rcp[com];

        int result = 0;
        
        if(player == com) result = 0;//비김
        else if ((player==1 && com ==2) && (player==2 && com ==3) && (player==3 && com == 1)) result = -1; //짐
        else result = 1; //이김

        return result;
    }

    public void win_incre(Player p){
        dao.winIncre(p);
    }   
    public void lose_incre(Player p){
        dao.loseIncre(p);
    }   
    public void total_incre(Player p){
        dao.totalIncre(p);
    }


    public void ranklist(){
        ArrayList<Player> result = dao.ranklist();
        for(Player player: result) System.out.println(player);
    }
}